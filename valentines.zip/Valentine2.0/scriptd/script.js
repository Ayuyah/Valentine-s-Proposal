const noBtn = document.querySelector(".no");
noBtn.addEventListener("mouseenter", moveButton);

function moveButton() {
  const page = document.querySelector(".page2");

  const maxX = page.clientWidth - noBtn.offsetWidth;
  const maxY = page.clientHeight - noBtn.offsetHeight;

  const randomX = Math.floor(Math.random() * maxX);
  const randomY = Math.floor(Math.random() * maxY);

  noBtn.style.position = "absolute";
  noBtn.style.left = randomX + "px";
  noBtn.style.top = randomY + "px";
}

// Auto-grow for textarea
function autoGrow(textarea) {
  textarea.style.height = "auto";
  textarea.style.height = textarea.scrollHeight + "px";
}

// Sending the message via EmailJS
function sendMessage() {
  const msgBox = document.getElementById("message");
  const msg = msgBox.value.trim();
  const response = document.getElementById("response");

  if (msg === "") {
    response.innerText = "Ama uko shy 😅";
    response.style.opacity = 1;
    return;
  }

  emailjs.send("service_tw9ppoe", "template_6up77ny", {
    message: msg
  })
  .then(() => {
    response.innerText = "I've read it and it means more than you know 💖";
    response.style.opacity = 1;
    msgBox.value = "";
  })
  .catch(() => {
    response.innerText = "Something went wrong, but your words still matter 💌";
    response.style.opacity = 1;
  });
}

// Initialize EmailJS with your public key
(function() {
  emailjs.init("oWTb7ROdd_eLZWr0a");
})();